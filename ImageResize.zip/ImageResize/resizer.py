import glob, os
from PIL import Image
try:
	iw = int(input("Finished Image Width? "))
	ih = int(input("Finished Image Height? "))
except:
	print("Not a Valid Number.")
	exit()
f = input("Completed Image Filetype (Including the Dot)? ")
t = -1
fcount = len(glob.glob("Images/*"))
for filename in glob.glob("Images/*"):
    t+=1
    x = t+1.00
    y =  fcount + 0.00
    print(str(round((x/y) * 100, 2)) + "%", end="\r")
    try:
    	image  = Image.open(filename)
    except:
    	print("Images failed to open. Possibly corrupt or damaged image file.")
    	exit()
    w  = image.size[0]
    h = image.size[1]
    aspect = w / float(h)
    ideal_aspect = iw / float(ih)
    if (aspect > ideal_aspect):
        new_width = int(ideal_aspect * h)
        offset = (w - new_width) / 2
        resize = (offset, 0, w - offset, h)
    else:
        new_height = int(w / ideal_aspect)
        offset = (h - new_height) / 2
        resize = (0, offset, w, h - offset)
    g = image.crop(resize).resize((iw, ih), Image.ANTIALIAS)
    if 1==1:
    	g.save("Finished/"  + format(t, "0" + str(len(str(fcount))) + "d") + f)	